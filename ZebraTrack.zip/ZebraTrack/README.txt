*** Please note that the following instructions can also be found in the file named "ZebraTrack.ipynb"

--- How to get the best out of ZebraTrack ---

Please read the current section to ensure that your videos will be adequately analyzed by ZebraTrack.

 - ZebraTrack has only been trained on grayscale 480x640 resolution videos. Therefore, videos of any other format may
	not work with the program.
 - While video frame rate can be specified on input, the default is assumed to be 30Hz. Videos of a higher frame rate
	are accepted, whereas videos of a lower frame rate will not work.
 - Videos where the larva initiates a second swim pattern, unstimulated, will be analyzed but the results may include this
	second swim pattern and should be interpreted with caution.
 - Videos where the fish is occluded (by experimenter hair, for instance) are more likely to generate errors. However, 
	ZebraTrack has been designed to effectively avoid distractor objects such as hands and forceps.
 - Videos that contain long periods of inactivity (i.e. where the larva is not swimming) are more likely to generate errors.
 - The IDEAL video for ZebraTrack is as follows:
	1. The experimenter stimulates the fish around 1 second into the video
	2. The larva executes only one swim pattern
	3. The video ends around 1 second after the larva stops swimming.
 - While ZebraTrack is an excellent tool, it is not perfect. You may find that some tracking data in the excel file
	contains lots of zeros in the swim distance column. If this is the case, feel free to delete these rows,
	which may appear either before or after the fish's swim pattern, to narrow down the tracking data.


--- ZebraTrack Use Instructions ---

Step 1: Make sure you have imported the ZebraTrack folder into your Google Drive's 
"Colab Notebooks" folder. If you do not have one, you can create one:

	1. Navigate to "My Drive" on the Google Drive website
	2. Press the plus button located in the top left of your screen, then select "new folder"
	3. Name the new folder "Colab Notebooks"
	4. Place the "ZebraTrack" folder under "Colab Notebooks"
	5. Proceed with Step 2.


Step 2: Upload videos. If you have not already, this step will guide you through 
uploading videos so that you may run ZebraTrack on these videos.

	1. To use ZebraTrack, you must upload at least one black and white, 480x640 resolution .avi video 
		to ZebraTrack's "videos" folder. The easiest way to do so is to drag and drop a folder into 
		ZebraTrack's Google Drive folder, and rename this folder "videos".
	2. N.B. ZebraTrack can only analyze ONE TREATMENT GROUP at a time. This is 
		because it places all your videos into one excel file. It will not distinguish 
		videos based on their name. That is, if you have four treatment groups to analyze, 
		you must run ZebraTrack four times; e.g., the first time you will upload only 
		WT videos, then mutant videos, etc.


Step 3: Run the hidden cell below by clicking the play button at the bottom left of this text. 
This will run all the necessary code for you to use ZebraTrack in the next step. 

	1. If you have never used Google Colaboratory before, you will need to grant 
		it access to your google drive. When you press run on the "Setup" cell, 
		it will prompt you to connect to Google Drive. 
	2. You must give Google Colaboratory full access to your Google Drive 
		so that it can read and write files stored in this location. If this 
		step is not completed, then the program will not work.
	3. N.B. Any time you change the contents of your Google Drive, you MUST 
		run the setup cell again in order to ensure that ZebraTrack has access to your latest files.
	4. Proceed with Step 4.


Step 4: Press run on the cell below. If all goes well, the shell should 
be firing out predictions as it runs the model on your videos. This will appear as 
several lines of text rapidly being printed out. Once it has finished running, you 
will find an excel file, titled "videos_results.xlsx" in your "videos" folder in Google Drive.

	1. The average run time for the analysis of 20 videos is roughly 10 minutes.
	2. ZebraTrack also outputs a folder named "predictions", which contains csv files. Each csv file
		represents the tracking data for a single larva in an ImageJ friendly format if you wish to make
		changes to or visualize the tracking data post-hoc. (N.B. these csvs are formatted to be used with 
		ImageJ's "manual tracking" plugin)
	3. If you would like to run ZebraTrack again, simply empty the videos folder, and repeat starting from Step 2.

----------------------------------